import { ArrowBackIosRounded, ArrowUpwardRounded } from "@material-ui/icons"
import "./movie.scss"

export default function Movie() {
        return(
            <div className="movie">
                <div className="back">
                    Snow Board
                </div>
                <video className="movie" autoPlay progress controls src="https://videos.pond5.com/aerial-flying-over-mountain-ridge-footage-048002948_main_xxl.mp4"></video>
                
            
            </div>


        )



}




