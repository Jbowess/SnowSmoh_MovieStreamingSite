import "./cover.scss"

export default function Cover() {
        return(
            <div className="cover" style={{backgroundImage: "url('https://adwallpapers.xyz/uploads/posts/70858-snowy-mountains-4k-ultra-hd-wallpaper__nature.jpg')"}}>
                <div className="top"></div>
                <div className="element"></div>
                <div className="logo">S.</div>
                <div className="header">SnowSmoh.</div>
                <div className="bottom"></div>









                
            
            </div>


        )



}




