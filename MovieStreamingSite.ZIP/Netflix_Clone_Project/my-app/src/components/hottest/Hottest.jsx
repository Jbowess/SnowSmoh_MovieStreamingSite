import { InfoOutlined, InfoRounded, InfoSharp, InvertColorsOffSharp, PlayArrow, PlayCircleFilledRounded } from "@material-ui/icons";
import "./hottest.scss";

export default function Hottest() {
  return (
    <div className='hottest'>
           <img src="https://c4.wallpaperflare.com/wallpaper/133/616/20/inception-movies-wallpaper-preview.jpg" alt="" />

       <div className="info">
           <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAaQAAAB4CAMAAACKGXbnAAAAkFBMVEX////SAADYRUXPAADhZmb55ubVAAD+8/PXOzv76urpmZn219fVCAjgbGzWLy/toqLup6fdVVXxs7PYQUHzysr+9fX/+vr44eHuq6vlf3/0wMD53NzWKyvYNzfke3vWIyPzxcXeZ2fVFxfoi4vdTk7jc3PnkJDmhITeWVnsrq7pjo7XJyf20dHXGhrdWFjrm5t7xiMkAAAHNUlEQVR4nO2baXuqOhRGE4NVa48TiooTtVRta9v//++uA5kTtGjhPOe+65sS2CQrwE4IhAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMD/ncY+id96kzhOZlHV51KM+jA+1OAtTvaNqk/lQGtRO7GY6f8/h+e/2+YOcfO0IQxGviP2ds0nyo5QugqDuGUXqflpbrSSHWNz2g/eh9YR62YxncVQKTs5V6AW+ppkNHtJ5zSrwXqxm9gVyJieGymcWBXkrerd9UfU6Rlm2Aiz/z/MMAN23rBwd7HZ8iErwGHrpXmM1gP1wqba6TFHCfa03OsHHDuKqXvEStnHrOyDp0UGKdWPxujS6qpngqwgM05HtCqte4L8DJ+kGg/TMWRwSU2XpPqrq7UYm+qFW085LXpR0umQfU38/SQNPp016I9dhQNRwLBUtiSaGrXIkRTPfY0112pxuyTKVuot7F6SWkvfEdY9R3EpqanbKF0Se9E25Eia5DXVQCl4B0mHRlbO+E6S6s2c4/yxy0tJVH/ClS6Jskd1g1/SRq1hljiIn6FaPE/S5WeSQKYu95E01nfSa0DZl5WpKpJY4GrV8iTpV4FX0kQ541V/2Z30XoIm/2eu5YJCUvjVN0m1LiEkhVlKNpdPdbYVxcbrjmCdbVb++kyUQ3ol1edKlZvP773J9zJdS0/s1dxDkUSpesOpQhJV8nOfJNkNGd3wx+worp2KGzkil2RlRfbp8fwpq21UH77IZhNHjeotTmOXbQzkf3X1GvBK2kn9u4R3qrZ6f+gae2iSqJKIVyJpLS15JEWpqGGgbRkuGDPTdSFpSC5gSjoy7vBI365deMs5niEnfJKkjVWi/t/4I+UZba5LUmpTiSSaimb2SBqImpg3hcZ0ZY2TbpJE9jxU4NqloKSGqOvCSLejja9uuiS6Fm1YjSTa5xs8kkT51J4IslKMGyVFXzyWa5eCkqQJu2Hl6E/3Z0iiHd4bK5IknppuSYnoTddMhNwoibxnwULXzGAxSY0Vr8HA3iXircGWzlDSEj/tciXJjCd7ALglbXljbsgVFE8czrxkp1S7n6Qhv1icV2cikkwtIg/FH5IHieft5Upi3WdxqZ8HG25Jn/wwV52VSMGnva7Ot3FrdN/u+nkNWkzSlAdyzSyQxiI76FrrVjzUUtwrs05asqQJSZlWxC2Jl1lfFVQOZpmJ8dB2Sop5NKeHYpK4d+q+XQsL6rBYCbUVXfk0zCtZUo80+OiQro4t6JTU4ufozLcs/DMO10hKxGUbEwfFJPHbuzmfnMFnvJj2xJKhRvKGk5AKJMmMl9ZGHkkzXocpuYYCkkS04VYU/nQ2aCFJIz43krpfk8XOu6ESaiS68nFMWb4kmbqx2gVJ9Lck0YczVJlPY2/OgxeS1LhVEqmL9PAwLKxAkpzeZlu3JNGWu6uCFpDkwJk23Hq7m7tvd28XbncH9uJN5oK0KpBElsJSL85NHJ6uCiokWXnD9ZKsuSZOJYnDEZHPsNdKJElLlM/R6ZJEqzvfYJqIcdJk1jYwRj7+l35L3xKXYpJ4Bd3zgSO+muBTayYj1Lc4OTHKLVVSg8/ECHRJoo76G0IPP59xMAkd8wIZxSSJy8A5izHkcWu5oZbW2ZYqiTTMtSO6pPhHp3WLpGPmkCa+pUqkqCT5mLSW/hzgtw+jD5qhor55uuVKIuO1Hl6XFInXe46pGmvyp4Ck4M+J1+2me2EuqeAEqxiOspm1y1TUWn9i2aEWVKdkSTIRd0kiXdGHzMaJNvTR+KvABOuYREeuqFFBSfKaXZkLuHpKcnsh1ExM41UjyVhnYkgaiT5kvPSbpcyq3K2z4LkUfeknHyhP2h0vkqNnatxlHaGGVKN0SWLy2SWJtBWF7yLHG56nS1hfuwZunQXPpagkkcEd0/uY1248UZZKmtNQrlCJ1pXLl0TUpY/WQpSN3JYtRHl/Fm+l2E493byFKP1n1yi5BEmkrT51F8FL76077a+U/6zM1RnqW9mjCkkj5VWgvaRLS0CtBVHq1Gvukq6PqiSRvXYRWDWwFgt5QqntUIEkEsmO5Vgc+Wjly0oN1ftd7uLITmWSyOwjZxZqa5f3hJIz4pVIIm1hybXMeKLeHDT0F7Z/qyRSf/acFFu5Rs+eUJFM8SqRJEetzgX7s52rK7KFkcX9tZIO/cz8KOQUnQXOKT1fKDmm/F1JoUeSmD/xzG/uX60PR/pWJ8z79IXe/Ew678KKSTpoCplRg4epPb7ND9XmvfA+ki58RNa0r/JNeOEjssevhXjsztOp42O/vI/Iwp32yrfz46+x+JddjmfIicsfkbW3tQ9eg3UzGFz8iMwOlX1qd6ePyH6F1j6JJ8ePGYf36UnlMx7GhxoM4qSdM0sIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/xr/AQGSbNy+my8RAAAAAElFTkSuQmCC" alt="" />
       
       <span className="desc">Inception is a 2010 science fiction action film written and directed by Christopher Nolan. The film stars Leonardo DiCaprio as a professional thief who steals information by infiltrating the subconscious of his targets.</span>
        <div className="buttons">
            <button className="play">
                <PlayCircleFilledRounded/>
                <span>Play</span>
            </button>
            <button className="more">
                <InfoRounded/>
                <span>Info</span>
            </button>
            </div>
        </div>
    </div>


  );
}


