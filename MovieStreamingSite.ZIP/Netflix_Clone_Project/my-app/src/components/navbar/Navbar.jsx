
import "./navbar.scss"
import {SearchRounded} from "@material-ui/icons"
import logo from "./flake.png" 

const Navbar = () => {
  return (
    <div className="navbar">

        <div className="container">
            <span>SnowSmoh.</span>
            <img src={logo} alt="" height="70" width="70"/>

            <div className="left">
                <span>SnowBoard</span>
            </div>
      
            <div className="dropdown">
                  <span>IcyTV</span>
                  <div className="choices">
                        <span>Movies</span>
                        <span>Series</span>
                        <span>Coldest</span>

                  </div>
            </div>

            <SearchRounded/>

            <div className="right">
                  <input type="text" placeholder="" color="white"/> 
            </div>


        </div>
    </div>
  )
}

export default Navbar