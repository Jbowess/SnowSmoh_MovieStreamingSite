import { Add, PlayArrow, PlayArrowOutlined, ThumbDown, ThumbUp, ThumbUpRounded } from '@material-ui/icons'
import './listItem.scss'

export default function ListItem() {

const movie = "https://www.youtube.com/watch?v=kV6iZRvilwc"

  return (
    <div className="listItem">
        <img src="https://m.media-amazon.com/images/M/MV5BYjZhZmM0ZDktNDU3YS00YTI3LWJiNjAtZjg2MjkwNzNiODU3XkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_.jpg" alt="" />

      <div className="itemInfo">
        <div className="icons">
          <PlayArrowOutlined/> 
          <ThumbUpRounded/>
          <ThumbDown/>
          <span>                            </span>
        </div>
        <div className="genre">Adventure, Thriller, Action</div>
      <div className="itemInfoTop">
        <span>2 hours 11 mins </span>
        <span>2012</span>
      </div>
      <div className="desc">
      The story of the deadliest day on the world's most dangerous mountain.
      </div>

    </div>
  </div>
  )
};
