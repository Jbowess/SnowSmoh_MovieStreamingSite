import Home from "./pages/home/Home";
import "./app.scss"
import Movie from "./pages/home/movie/Movie";
import Cover from "./pages/home/cover/Cover";


const App = () => {
  return <Home/>;
};

export default App;

